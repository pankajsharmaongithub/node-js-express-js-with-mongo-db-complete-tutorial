const data={name:'pankaj sharma',role:"Web Developer",age:30}
module.exports={data:data}