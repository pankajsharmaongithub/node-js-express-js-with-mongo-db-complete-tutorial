let x=12121212121

module.exports={x:x,y:()=>{return 222;}}